### HOW TO RUN THE CODE

yarn install

yarn dev